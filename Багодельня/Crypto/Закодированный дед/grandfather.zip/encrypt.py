import argparse
import os

def xor_encrypt_bmp_advanced(input_file, output_file, key):
    try:
        if not os.path.exists(input_file):
            print(f"Ошибка: файл {input_file} не найден")
            return False
            
        with open(input_file, 'rb') as f:
            bmp_data = bytearray(f.read())
        
        key_bytes = key.encode('utf-8')
        key_length = len(key_bytes)
        
        start_index = 0
            
        for i in range(start_index, len(bmp_data)):
            bmp_data[i] ^= key_bytes[(i - start_index) % key_length]
            
        with open(output_file, 'wb') as f:
            f.write(bmp_data)
        
        print(f"Успешно: {input_file} -> {output_file}")
        print(f"Размер файла: {len(bmp_data)} байт")
        print(f"Зашифровано байт: {len(bmp_data) - start_index}")
        
        return True
        
    except Exception as e:
        print(f"Произошла ошибка: {e}")
        return False

def main():
    parser = argparse.ArgumentParser(description='Шифрование BMP изображения с помощью XOR')
    parser.add_argument('input', help='Входной BMP файл')
    parser.add_argument('-o', '--output', help='Выходной файл', default='encrypted.bmp')
    parser.add_argument('-k', '--key', help='Ключ для XOR', default='xxxxxxxxxx')
    
    args = parser.parse_args()
    
    xor_encrypt_bmp_advanced(
        input_file=args.input,
        output_file=args.output,
        key=args.key
    )


# python encrypt.py image.bmp -o encrypted.bmp -k "ключ-длиной-10-байт"

if __name__ == "__main__":
    main()